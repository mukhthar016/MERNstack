import React from 'react';


export default function Start() {
  return (
    <div>
      <p>
     vaidyakiya sahayaka
      </p>
    </div>
  );
}

